﻿using Northwind.Data.Dtos;
using Northwind.Data.Services;
	// __LLBLGENPRO_USER_CODE_REGION_START SsSvcAdditionalNamespaces 
	// __LLBLGENPRO_USER_CODE_REGION_END 

namespace Northwind.Data.ServiceInterfaces
{ 
    public interface IProductServiceRepository: IEntityServiceRepository<Product>
	// __LLBLGENPRO_USER_CODE_REGION_START SsSvcAdditionalInterfaces 
	// __LLBLGENPRO_USER_CODE_REGION_END 
    {
        EntityMetaDetailsResponse GetEntityMetaDetails(ServiceStack.ServiceInterface.Service service);
        DataTableResponse GetDataTableResponse(ProductDataTableRequest request);

        ProductCollectionResponse Fetch(ProductQueryCollectionRequest request);
        ProductResponse Fetch(ProductPkRequest request);

        ProductResponse Fetch(ProductUcProductNameRequest request);

        ProductResponse Create(ProductAddRequest request);
        ProductResponse Update(ProductUpdateRequest request);
        SimpleResponse<bool> Delete(ProductDeleteRequest request);
    
	// __LLBLGENPRO_USER_CODE_REGION_START SsSvcAdditionalMethods 
	// __LLBLGENPRO_USER_CODE_REGION_END 

    } 
}
